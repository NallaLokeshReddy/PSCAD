//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// C-Course Demo
//------------------------------------------------------------------------------
// This is a demo that is part of the C-Course for creating EMTDC components
// that are primarily written in C. 
//
// Created By:
// ~~~~~~~~~~~
//    LOKESH NALLA <lokeshreddy224@gmail.com>
//     ABB GISPL.
//     Bangalore, INDIA
//
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#define _CRT_SECURE_NO_WARNINGS

// This are the data types that can be passed into a C function from Fortran
// The first set is defined if it was passed by GCC, the second set is defined
// if passed by the Intel Compiler.
//
#ifdef __GNUC__
#define REAL(param)          double * param
#define INTEGER(param)       int * param
#define COMPLEX(param)       FCmplx * param
#define LOGICAL(param)       int * param
#define REAL_ARR(param)      double * param
#define INTEGER_ARR(param)   int * param
#define COMPLEX_ARR(param)   FCmplx * param
#define LOGICAL_ARR(param)   int * param
#define FUNCTION(func_name)  func_name##_
typedef struct { double real; double imag; } FCmplx;
#else
#define REAL(param)          double * param
#define INTEGER(param)       int * param
#define COMPLEX(param)       FCmplx * param
#define LOGICAL(param)       int * param
#define REAL_ARR(param)      double param[]
#define INTEGER_ARR(param)   int param[]
#define COMPLEX_ARR(param)   FCmplx param[]
#define LOGICAL_ARR(param)   int param[]
#define FUNCTION(func_name)  func_name
typedef struct { double real; double imag; } FCmplx;
#endif

// Dependencies
#include <stdlib.h>
#include <string.h>
#include <math.h>

// ------------------------------------------------------------
//  This enumerable is used to indicate how the structure
//  should be read from the storage
// ------------------------------------------------------------
enum StatusTypes 
{
   INITIALIZE = 0,  // When initializing there is no values already being used.
   FINALIZE = 1,    // When finalizing we need to clean up the memory that was allocated
   SERIALIZE = 2,   // When Serializing all memory must be written to the storage arrays in a serialized fasion
   DESERIALIZE = 3, // When Deserializing all values can be read to reconstruct the structure heirarchy
   NORMAL = 4       // When running normally the values can simply be read as is.
};

// ------------------------------------------------------------
// The structure that contains the state information
// ------------------------------------------------------------
typedef struct {
   int iValue;
   double dValue;
   char sString[32];
   double dArray[5];
} InnerStruct;

typedef struct {
   int iValue;
   double dValue;
   char sString[32];
   double dArray[5];
   InnerStruct* pObject;
} DemoStruct;

// ------------------------------------------------------------
// Internal function headers
// ------------------------------------------------------------
int doTheThing(int input, DemoStruct* data);
void initialize(DemoStruct* data);
void finalize(DemoStruct* data);
void serialize(DemoStruct* data, int nstori, int* stori);
void deserialize(DemoStruct* data, int nstori, int* stori);

int getIntSize(int size);
int getTotalSize();

// ------------------------------------------------------------
// Function (C) for the Fortran function in
// the memorydemo1 definition
// ------------------------------------------------------------
void FUNCTION(memorydemo1)(INTEGER(N1), INTEGER(N2), INTEGER(STATUS), INTEGER(NSTORI), INTEGER_ARR(STORI))
{
   // When Intialize or deserializing ensure it is done before using the values
   //
   DemoStruct * ptr = (DemoStruct*)&(STORI[*NSTORI]);
   if (*STATUS == INITIALIZE)
      initialize(ptr);
   else if (*STATUS == DESERIALIZE)
      deserialize(ptr, *NSTORI, STORI);

   // Call an internal function to perform the operation
   //
   (*N2) = doTheThing(*N1, ptr);

   // If finalizing or serializing perform the action after the
   // operation has taken place.
   //
   if (*STATUS == FINALIZE)
      finalize(ptr);
   else if (*STATUS == SERIALIZE)
      serialize(ptr, *NSTORI, STORI);

   // Increment the storage counter to that it is now after
   // the values used by this function. This counter must be incremented by the total amount of
   // porential storage that could be used by the entire structure. This will ensure that
   // the snapshots can actually be taken correctly.
   //
   (*NSTORI) += getTotalSize();
}

// ------------------------------------------------------------
// initialize()
//
// Give the starting values to the data object
// ------------------------------------------------------------
void initialize(DemoStruct* data)
{
   data->iValue = 3;
   data->dValue = 3.14;
   data->dArray[0] = 1.2;
   data->dArray[1] = 2.2;
   data->dArray[2] = 3.2;
   data->dArray[3] = 4.2;
   data->dArray[4] = 5.2;
   strncpy(data->sString, "String Value", 32);

   // We will need to allocate memory for the internal object.
   //
   data->pObject = malloc(sizeof(InnerStruct));
   data->pObject->iValue = 3;
   data->pObject->dValue = 3.14;
   data->pObject->dArray[0] = 1.2;
   data->pObject->dArray[1] = 2.2;
   data->pObject->dArray[2] = 3.2;
   data->pObject->dArray[3] = 4.2;
   data->pObject->dArray[4] = 5.2;
   strncpy(data->pObject->sString, "Inner Value", 32);
}

// ------------------------------------------------------------
// finalize()
//
// This is used to free internal memory allocation after a run
// is complete. If this is not done then a memory leak can
// occur that could make multi-run simulation unstable.
// ------------------------------------------------------------
void finalize(DemoStruct* data)
{
   free(data->pObject);
   data->pObject = NULL;
}

// ------------------------------------------------------------
// serialize()
//
// Ensure all memory for all internal structures are written
// in the storage arrays
// ------------------------------------------------------------
void serialize(DemoStruct* data, int nstori, int* stori)
{
   memcpy(&stori[nstori + getIntSize(sizeof(DemoStruct))], data->pObject, sizeof(InnerStruct));
}

// ------------------------------------------------------------
// deserialize()
//
// Load the memory to construct the internal storage for this
// component.
// ------------------------------------------------------------
void deserialize(DemoStruct* data, int nstori, int* stori)
{
   // During deserialization we must allocate the memory for the structure heiracrchy
   //
   data->pObject = malloc(sizeof(InnerStruct));

   // the data will need to be read from the storage arrays
   //
   memcpy(data->pObject, &stori[nstori + getIntSize(sizeof(DemoStruct))], sizeof(InnerStruct));
}

// ------------------------------------------------------------
// doTheThing()
//
// Do the math this is supposed to do
// ------------------------------------------------------------
int doTheThing(int input, DemoStruct* data)
{
   int i, n;
   double value;

   // Perform math on input value to get output value
   //
   value = input + data->iValue * data->pObject->iValue;
   data->iValue++; // update the value after using it
   data->pObject->iValue--; // update the value after using it


   n = 5;
   for (i = 0; i < n; i++)
   {
      value += (pow(-1, i) * data->dArray[i] + data->pObject->dArray[i]);
      data->dArray[i] *= 1.1; // Update the values in each array after using them
      data->pObject->dArray[i] /= 1.1; // Update the values in each array after using them
   }

   value += data->dValue - data->pObject->dValue/2;
   data->dValue *= 1.01; // update the value after using it
   data->pObject->dValue /= 1.01; // update the value after using it

   return (int)value;
}

// ------------------------------------------------------------
// getIntSize()
//
// This will convert a sizeof (...) statement to give the number
// of 'int' spaces that must be used to store the total size
// of the structure.
// ------------------------------------------------------------
int getIntSize(int size)
{
   return 
      (size / sizeof(int)) // Get the number of ints/
      + ((size % sizeof(int) == 0) ? 0 : 1); // We always need to round up.
}

// ------------------------------------------------------------
// getTotalSize()
//
// Get the total amount of storage used by this component.
// The storage arrays must be maintained using the correct offsets
// Even when not serializing or deserializing it must increment
// the same amount, so the total size will always need to be
// the maximum size that this component may take.
// ------------------------------------------------------------
int getTotalSize()
{
   return getIntSize(sizeof(DemoStruct)) + getIntSize(sizeof(InnerStruct));
}

