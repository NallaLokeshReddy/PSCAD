//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// C-Course Demo
//------------------------------------------------------------------------------
// This is a demo that is part of the C-Course for creating EMTDC components
// that are primarily written in C. 
//
// Created By:
// ~~~~~~~~~~~
//     LOKESH NALLA <lokeshreddy224@gmail.com>
//     ABB GISPL.
//     Bangalore, INDIA
//
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

// This are the data types that can be passed into a C function from Fortran
// The first set is defined if it was passed by GCC, the second set is defined
// if passed by the Intel Compiler.
//
#ifdef __GNUC__
   #define REAL(param)          double * param
   #define INTEGER(param)       int * param
   #define COMPLEX(param)       FCmplx * param
   #define LOGICAL(param)       int * param
   #define REAL_ARR(param)      double * param
   #define INTEGER_ARR(param)   int * param
   #define COMPLEX_ARR(param)   FCmplx * param
   #define LOGICAL_ARR(param)   int * param
   #define FUNCTION(func_name)  func_name##_
   typedef struct { double real; double imag; } FCmplx;
#else
   #define REAL(param)          double * param
   #define INTEGER(param)       int * param
   #define COMPLEX(param)       FCmplx * param
   #define LOGICAL(param)       int * param
   #define REAL_ARR(param)      double param[]
   #define INTEGER_ARR(param)   int param[]
   #define COMPLEX_ARR(param)   FCmplx param[]
   #define LOGICAL_ARR(param)   int param[]
   #define FUNCTION(func_name)  func_name
   typedef struct { double real; double imag; } FCmplx;
#endif

// Dependencies
#include <stdlib.h>
#include <string.h>
#include <math.h>

// ------------------------------------------------------------
// The structure that contains the state information
// ------------------------------------------------------------
typedef struct {
   int iValue;
   double dValue;
   char sString[32];
   double dArray[5];
   } DemoStruct;

// ------------------------------------------------------------
// Internal function headers
//
int doTheThing(int input, DemoStruct* data);
void initialize(DemoStruct* data);

// ------------------------------------------------------------
// Function (C) for the Fortran function in
// the memorydemo1 definition
// ------------------------------------------------------------
void FUNCTION(memorydemo1)(INTEGER(N1), INTEGER(N2), LOGICAL(INIT), INTEGER(NSTORI), INTEGER_ARR(STORI))
{
    // Extract the value being used from the storage array
    //
    DemoStruct data;
    if (*INIT)
        initialize(&data);
    else
        memcpy(&data, &STORI[*NSTORI], sizeof(DemoStruct));

    // Call an internal function to perform the operation
    //
    (*N2) = doTheThing(*N1, &data);

    // Copy the data back to the storage array
    //
    memcpy(&STORI[*NSTORI], &data, sizeof(DemoStruct));

    // Increment the storage counter to that it is now after
    // the values used by this function
    //
    (*NSTORI) += sizeof(DemoStruct)/sizeof(int);
}

// ------------------------------------------------------------
// Function (C) for the Fortran function in
// the memorydemo2 definition
// ------------------------------------------------------------
void FUNCTION(memorydemo2)(INTEGER(N1), INTEGER(N2), LOGICAL(INIT), INTEGER(NSTORI), INTEGER_ARR(STORI))
{
    // Convert the array passed in directly to the structure
    //
    DemoStruct * ptr = (DemoStruct*)&(STORI[*NSTORI - 1]);
    if (*INIT)
       initialize(ptr);

    // Call an internal function to perform the operation
    //
    (*N2) = doTheThing(*N1, ptr);

    // Increment the storage counter to that it is now after
    // the values used by this function
    //
    (*NSTORI) += sizeof(DemoStruct) / sizeof(int);
}

// ------------------------------------------------------------
// initialize()
//
// Give the starting values to the data object
// ------------------------------------------------------------
void initialize(DemoStruct* data)
{
    data->iValue = 3;
    data->dValue = 3.14;
    data->dArray[0] = 1.2;
    data->dArray[1] = 2.2;
    data->dArray[2] = 3.2;
    data->dArray[3] = 4.2;
    data->dArray[4] = 5.2;
    strncpy(data->sString, "String Value", 32);
}

// ------------------------------------------------------------
// doTheThing()
//
// Do the math this is supposed to do
// ------------------------------------------------------------
int doTheThing(int input, DemoStruct* data)
{
    int i, n;
    double value;

    // Perform math on input value to get output value
    //
    value = input + data->iValue;
    data->iValue++; // update the value after using it

    n = 5;
    for (i = 0; i < n; i++)
    {
        value += (pow(-1, i) * data->dArray[i]);
        data->dArray[i] *= 1.1; // Update the values in each array after using them
    }

    value += data->dValue;
    data->dValue *= 1.01; // update the value after using it

    return (int)value;
}

