//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// C-Course Demo
//------------------------------------------------------------------------------
// This is a demo that is part of the C-Course for creating EMTDC components
// that are primarily written in C. 
//
// Created By:
// ~~~~~~~~~~~
//    LOKESH NALLA <lokeshreddy224@gmail.com>
//     ABB GISPL.
//     Bangalore, INDIA
//
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

// This are the data types that can be passed into a C function from Fortran
// The first set is defined if it was passed by GCC, the second set is defined
// if passed by the Intel Compiler.
//
#ifdef __GNUC__ 
   #define REAL(param)          double * param
   #define INTEGER(param)       int * param
   #define COMPLEX(param)       FCmplx * param
   #define LOGICAL(param)       int * param
   #define REAL_ARR(param)      double * param
   #define INTEGER_ARR(param)   int * param
   #define COMPLEX_ARR(param)   FCmplx * param
   #define LOGICAL_ARR(param)   int * param
   #define FUNCTION(func_name)  func_name##_
   typedef struct { double real; double imag; } FCmplx;
#else
   #define REAL(param)          double * param
   #define INTEGER(param)       int * param
   #define COMPLEX(param)       FCmplx * param
   #define LOGICAL(param)       int * param
   #define REAL_ARR(param)      double param[]
   #define INTEGER_ARR(param)   int param[]
   #define COMPLEX_ARR(param)   FCmplx param[]
   #define LOGICAL_ARR(param)   int param[]
   #define FUNCTION(func_name)  func_name
   typedef struct { double real; double imag; } FCmplx;
#endif

// ------------------------------------------------------------
// Function (C) for the Fortran function in
// the memorydemo1 definition
// ------------------------------------------------------------
void FUNCTION(memorydemo1)(INTEGER(N1), INTEGER(N2), INTEGER(N3))
{
    // Perform the operation, let the component handle the storage
    //
    if (*N3 % 2)
        *N2 = *N1 * 3;
    else
        *N2 = *N1 * 7;

    *N3 += 1;
}

// ------------------------------------------------------------
// Function (C) for the Fortran function in
// the memorydemo2 definition
// ------------------------------------------------------------
void FUNCTION(memorydemo2)(INTEGER(N1), INTEGER(N2), INTEGER(NSTORI), INTEGER_ARR(STORI))
{
    // Extract the value being used from the storage array
    //
    int stored_value = STORI[*NSTORI-1];
    // Perform operation
    //
    if (stored_value % 2)
        *N2 = *N1 * 5;
    else
        *N2 = *N1 * 9;
    stored_value += 3;

    // Store the value back in the storage array
    //
    STORI[*NSTORI-1] = stored_value;

    // Increment the storage counter to that it is now after
    // the values used by this function
    //
    (*NSTORI) += 1;
}





